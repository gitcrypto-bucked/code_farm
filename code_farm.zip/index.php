<?php

require_once('vendor/autoload.php');
include_once('public/index.php');

?>