<?php
declare(strict_types= 1);

namespace bootstrap;

return \app\Application::configure($basepath= dirname(__DIR__,1), $projetfolder = 'code_farm', $boot ="NORMAL");
