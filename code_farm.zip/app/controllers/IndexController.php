<?php

namespace app\controllers;

use app\Controller;

use app\Validade;

use app\views\View;

class IndexController extends \app\Controller
{
    protected function after()
    {
        Validate::blockMethods(['POST', "PUT", "DELETE"]);
    }

    public function indexAction()
    {
        $View = new View();
        $View-> render("home/index"); 
    }


    protected function before()
    {

    }
}
?>