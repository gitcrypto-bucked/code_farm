<?php
define('APP_START', microtime(true));

require_once('./bootstrap/app.php');

use route\Router;

$route = new Router();

$route->setNamespace('\app\controllers');

$route->get('/',"IndexController@indexAction");

$route->run();

