<?php

declare(strict_types=1);

namespace request;

class Requisition
{
    const CALL = 200;
    const INVOKE = 300;


    public function handle($type, $fn, $params)
    {
        list($controller, $method) = explode('@', $fn);
        if($type==self::CALL)
        {
            $controller = new $controller($params);
            $className = get_class($controller);
            $methodVariable = array($controller,  $method);

            if(is_callable($methodVariable, true, $className)==true)
            {
              
                $value1 = call_user_func($methodVariable, $params);exit;
            }
            else  
            {
                self::handle( self::INVOKE, $fn, $params);
            }
        }
        if($type==self::INVOKE)
        {
            $reflectedMethod = new \ReflectionMethod($controller, $method);
            if (class_exists($controller) & ($reflectedMethod->isStatic()==false) )
            {
                $controller = new $controller($params);
                $reflectionClass = new \ReflectionClass(get_class($controller));
                $reflectionMethod = $reflectionClass->getMethod(strval($method));
                $reflectionMethod->setAccessible(true); 
                $reflectionMethod->invoke(new $controller($params)); 
            }
        }
    }

}

?>