<?php

namespace interfaces;

Interface  IFactoryConnection
{
    public static function getConnection();
}